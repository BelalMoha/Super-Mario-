package thd.game.managers;

import thd.game.level.*;
import thd.game.utilities.GameView;
import thd.gameobjects.movable.CheepCheep;
import thd.gameobjects.movable.Mario;
import thd.gameobjects.unmovable.*;

import java.awt.event.KeyEvent;

class UserControlledGameObjectPool {
    protected CheepCheep cheepCheep;
    protected Time time;
    protected Mario mario;
    protected final GameView gameView;
    protected Platform platform;
    protected Background background;
    protected Background2 background2;
    protected Overlay overlay;
    protected Cloud cloud;
    protected Block block;
    protected Block block2;
    protected Block block3;
    protected GreenTube greenTube;
    protected Lives gameLives;
    protected Points gamePoints;
    protected Level level;

    protected UserControlledGameObjectPool(GameView gameView) {
        this.gameView = gameView;
    }
    protected void gameLoopUpdate() {
        Integer[] pressedKeys = gameView.keyCodesOfCurrentlyPressedKeys();
        for (int keyCode : pressedKeys) {
            processKeyCode(keyCode);
        }
    }

    private void processKeyCode(int keyCode) {
        if (keyCode == KeyEvent.VK_A) {
            mario.left();
        } else if (keyCode == KeyEvent.VK_D) {
            mario.right();
        } else if (keyCode == KeyEvent.VK_F) {
            mario.shoot();
        } else if (keyCode == KeyEvent.VK_SPACE) {
            mario.jump();
        }
    }
}
