package thd.game.managers;

import thd.game.level.*;
import thd.game.utilities.GameView;

import java.util.List;

class LevelManager extends GameWorldManager{
    private List<Level> levels;
    private int currentLevelIndex;
    private static final int LIVES = 10;
    protected LevelManager(GameView gameView) {
        super(gameView);
    }
    @Override
    protected void initializeLevel() {
        super.initializeLevel();
        initializeGameObjects();
    }

    /**
     * Die Methode initializeGameObjects() soll in Zukunft dazu genutzt werden um Spielelemente an ein neues Level anzupassen, z.B.
     * o Anpassungen für das Level am Hintergrund machen.
     * o Die Lebensanzeige aktualisieren.
     * o Den Punktestand aus dem vorherigen Level übernehmen.
     * o Einen Countdown neu starten.
     */
    private void initializeGameObjects() {
    }

    protected boolean hasNextLevel() {
        return currentLevelIndex < (levels.size() - 1);
    }

    protected void initializeGame() {
        levels = List.of(new Level1(), new Level2(), new Level3());
        currentLevelIndex = 0;
        level = levels.get(0);
        if (Level.difficulty == Difficulty.STANDARD) {
            lives = LIVES;
        } else {
            lives = LIVES * 10;
        }
        points = 0;
    }

    protected void switchToNextLevel() {
        if (!hasNextLevel()) {
            throw new NoMoreLevelsAvailableException("No more Levels available for this runtime");
        } else {
            currentLevelIndex++;
            level = levels.get(currentLevelIndex);
        }
    }

}
