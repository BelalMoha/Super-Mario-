package thd.game.managers;

import thd.game.level.Difficulty;
import thd.game.level.Level;
import thd.game.utilities.FileAccess;
import thd.game.utilities.GameView;
import thd.screens.EndScreen;
import thd.screens.StartScreen;

/**
 * Class Managing the Game.
 */
class GameManager extends LevelManager{
    protected GameManager(GameView gameView) {
        super(gameView);
    }
    @Override
    protected void gameLoopUpdate() {
        super.gameLoopUpdate();
        gameManagement();
    }
    @Override
    protected void initializeLevel() {
        super.initializeLevel();
        overlay.showMessage(level.name, 2);
    }
    private void gameManagement() {
        if (endOfGame()) {
            EndScreen endScreen = new EndScreen(gameView);
            endScreen.showEndScreen(points);
            startNewGame();
            gameView.stopAllSounds();
            if (gameView.timer(2000, this)) {
                overlay.stopShowing();
            }
        } else if (endOfLevel()) {
            switchToNextLevel();
            initializeLevel();
            if (!overlay.isMessageShown()) {
                overlay.showMessage("Great Job!");
                if (gameView.timer(2000, this)) {
                    overlay.stopShowing();
                }
            }
        }
    }
    private boolean endOfGame() {
        return lives == 0 || (!hasNextLevel() && endOfLevel());
    }
    @Override
    protected void initializeGame() {
        super.initializeGame();
        initializeLevel();
    }

    private boolean endOfLevel() {
        return countdown(20);
    }

    private boolean countdown(int x) {
        return gameView.timer(x * 1000, this);
    }

    void startNewGame() {
        StartScreen startScreen = new StartScreen(gameView);
        Difficulty difficulty = FileAccess.readDifficultyFromDisc();
        startScreen.showStartScreenWithPreselectedDifficulty(difficulty);
        difficulty = startScreen.getSelectedDifficulty();
        FileAccess.writeDifficultyToDisc(difficulty);
        Level.difficulty = difficulty;
        initializeGame();
        gameView.playSound("mariotheme.wav", true);
    }

}
