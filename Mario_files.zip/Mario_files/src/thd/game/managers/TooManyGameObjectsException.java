package thd.game.managers;

/**
 * Exception, if too many game objects have been created.
 */
public class TooManyGameObjectsException extends RuntimeException {
    /**
     * Exception with message.
     *
     * @param message Message to be shown.
     */
    public TooManyGameObjectsException(String message) {
        super(message);
    }
}
