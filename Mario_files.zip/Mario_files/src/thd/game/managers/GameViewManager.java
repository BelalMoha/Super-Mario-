package thd.game.managers;


import thd.game.utilities.GameView;

/**
 * Class that adapts the pieces to the Gameview.
 */
public class GameViewManager extends GameView {
    private GameManager gameManager;

    /**
     * Initialises the Game view with the visuals and pieces.
     */
    @Override
    public void initialize() {
        setWindowTitle("Super Mario Brothers 64");
        setStatusText("Belal Mohamed - Java Programmierung SS 2023");
        setWindowIcon("gameicon.png");
        gameManager = new GameManager(this);
        gameManager.startNewGame();
        showStatistic(false);
    }

    /**
     * starts the game and movement of pieces.
     */
    @Override
    public void gameLoop() {
        gameManager.gameLoopUpdate();
    }
}