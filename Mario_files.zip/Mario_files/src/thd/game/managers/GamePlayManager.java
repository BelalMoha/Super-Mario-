package thd.game.managers;

import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;
import thd.gameobjects.movable.Goomba;
import thd.gameobjects.movable.Turtle;

/**
 * The manager for gameplay itself.
 */
public class GamePlayManager extends WorldShiftManager {
    private final GameObjectManager gameObjectManager;
    protected int points;
    protected int lives;

    protected GamePlayManager(GameView gameView) {
        super(gameView);
        gameObjectManager = new GameObjectManager();
    }

    @Override
    protected void gameLoopUpdate() {
        super.gameLoopUpdate();
        gameObjectManager.gameLoopUpdate();
        gamePlayManagement();
    }
    /**
     * ALl lives are gone.
     *
     * @return activates when Mario can no longer go on.
     *
     *
     */
    private boolean livesLost() {
        return lives == 0;
    }

    /**
     * How many points.
     *
     * @return the amount of points
     */
    public int getPoints() {
        return points;
    }
    /**
     * Add points.
     *
     *  @param pts points to be added to score board
     */
    public void addPoints(int pts) {
        points += pts;
    }
    /**
     * Add a life.
     */
    private void addLife() {
        if (lives < 10) {
            lives += 1;
        }
    }
    /**
     * How many lives.
     *
     * @return the amount of lives
     */
    public int getLives() {
        return lives;
    }

    /**
     * Lose a life.
     */
    public void loseLife() {
        lives -= 1;
    }
    /**
     * private void gamePlayManagement() {
     *         if (currentNumberOfVisibleSquares < 5) {
     *             if (gameView.timer(1000, this)) {
     *                 spawnGameObject(new Turtle(gameView, this));
     *                 currentNumberOfVisibleSquares++;
     *             }
     *         }
     *         if (gameView.timer(1000, this)) {
     *             spawnGameObject(new CheepCheep(gameView, this));
     *         }
     *     }
     */
    private void gamePlayManagement() {
        if (gameView.timer(4000, this)) {
            spawnGameObject(new Goomba(gameView, this));
        }
        if (gameView.timer(6000, this)) {
            spawnGameObject(new Turtle(gameView, this));
        }
    }

    /**
     * Spawns a GameObject to be shown in GameView.
     *
     * @param gameObject The GameObject to be shown.
     */
    @Override
    public void spawnGameObject(GameObject gameObject) {
        super.spawnGameObject(gameObject);
        gameObjectManager.add(gameObject);
    }

    /**
     * Destroys a GameObject, it will not be shown in GameView anymore.
     *
     * @param gameObject The GameObject to be destroyed.
     */
    @Override
    public void destroyGameObject(GameObject gameObject) {
        super.destroyGameObject(gameObject);
        gameObjectManager.remove(gameObject);
    }

    @Override
    protected void destroyAllGameObjects() {
        super.destroyAllGameObjects();
        gameObjectManager.removeAll();
    }
}
