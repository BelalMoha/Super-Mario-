package thd.game.managers;

import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;
import thd.gameobjects.movable.*;
import thd.gameobjects.unmovable.*;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

class GameWorldManager extends GamePlayManager{
    private final List<GameObject> activatableGameObjects;
    protected GameWorldManager(GameView gameView) {
        super(gameView);
        activatableGameObjects = new LinkedList<>();
        cheepCheep = new CheepCheep(gameView, this);
        time = new Time(gameView, this);
        platform = new Platform(gameView, this);
        cloud = new Cloud(gameView, this);
        greenTube = new GreenTube(gameView, this);
        gameLives = new Lives(gameView, this);
        gamePoints = new Points(gameView, this);
        background = new Background(gameView, this);
        background2 = new Background2(gameView, this);
        overlay = new Overlay(gameView, this);
        block = new Block(gameView, this);
        block2 = new Block(gameView, this);
        block3 = new Block(gameView, this);
        mario = new Mario(gameView, this, greenTube);
    }

    private void spawnGameObjects() {
        spawnGameObject(gamePoints);
        spawnGameObject(gameLives);
        spawnGameObject(cheepCheep);
        spawnGameObject(time);
        spawnGameObject(platform);
        spawnGameObject(overlay);
        spawnGameObject(mario);
    }
    @Override
    protected void gameLoopUpdate() {
        super.gameLoopUpdate();
        activateGameObjects();
    }
    private void addActivatableGameObject(GameObject gameObject) {
        activatableGameObjects.add(gameObject);
        addToShiftableGameObjectsIfShiftable(gameObject);
    }
    private void spawnGameObjectsFromWorldString() {
        String[ ] lines = level.world.split("\\R");
        for (int lineIndex = 0; lineIndex < lines.length; lineIndex++) {
            for (int column = 0; column < lines[lineIndex].length(); column++) {
                double x = (column - level.worldOffsetColumns) * 100;
                double y = (lineIndex - level.worldOffsetLines) * 100;
                char character = lines[lineIndex].charAt(column);
                if (character == 'T') {
                    Turtle turtle = new Turtle(gameView, this);
                    turtle.getPosition().updateCoordinates(x, y - 30);
                    spawnGameObject(turtle);
                } else if (character == 'S') {
                    Block block = new Block(gameView, this);
                    block.getPosition().updateCoordinates(x, y-95);
                    spawnGameObject(block);
                    Block block2 = new Block(gameView, this);
                    block2.getPosition().updateCoordinates(x+500, y -100);
                    spawnGameObject(block2);
                    Block block3 = new Block(gameView, this);
                    block3.getPosition().updateCoordinates(x+1000, y -100);
                    spawnGameObject(block3);
                } else if (character == 'G') {
                    Goomba goomba = new Goomba(gameView, this);
                    goomba.getPosition().updateCoordinates(x, y - 30);
                    spawnGameObject(goomba);
                } else if (character == 'B') {
                    background.getPosition().updateCoordinates(x, y);
                    spawnGameObject(background);
                } else if (character == 'P') {
                    greenTube.getPosition().updateCoordinates(x, y - 100);
                    spawnGameObject(greenTube);
                } else if (character == 'C') {
                    cloud.getPosition().updateCoordinates(x, y);
                    spawnGameObject(cloud);
                } else if (character == 'X') {
                    background2.getPosition().updateCoordinates(x, y);
                    spawnGameObject(background2);
                }
            }
        }
    }

    protected void initializeLevel() {
        activatableGameObjects.clear();
        destroyAllGameObjects();
        spawnGameObjects();
        spawnGameObjectsFromWorldString();
    }
    private void activateGameObjects() {
        ListIterator<GameObject> iterator = activatableGameObjects.listIterator();
        while (iterator.hasNext()) {
            GameObject gameObject = iterator.next();
            if (gameObject instanceof Goomba) {
                Goomba goomba = (Goomba) gameObject;
                if (goomba.tryToActivate(Integer.valueOf(gameView.gameTimeInMilliseconds()))) {
                    spawnGameObject(goomba);
                    iterator.remove();
                }
            }
        }
    }
}
