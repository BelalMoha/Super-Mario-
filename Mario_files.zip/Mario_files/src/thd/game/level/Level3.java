package thd.game.level;

/**
 * The third level of Mario.
 */
public class Level3 extends Level{
    /**
     * Initialises the third level of Mario.
     */
    public Level3() {
        this.number = 3;
        this.name = "Level " + number + "\nLater that night";
        this.timeLimit = 240;
        this.world = """
                                      \s
                                      \s
                                      \s
                    X                 \s
                                      \s
                                      \s
                                      \s
                                      \s
                                      \s
                   P                  \s
          T          M       G G G T  \s""";
        this.worldOffsetColumns = 10;
        this.worldOffsetLines = 4;
    }
}
