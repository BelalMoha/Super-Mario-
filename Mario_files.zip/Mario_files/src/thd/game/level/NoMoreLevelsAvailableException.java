package thd.game.level;

/**
 * Exception when no more levels are available.
 */
public class NoMoreLevelsAvailableException extends RuntimeException{
    /**
     * Exception with message.
     *
     * @param message Message to be shown.
     */
    public NoMoreLevelsAvailableException(String message) {
        super(message);
    }
}
