package thd.game.level;

/**
 * The difficulties of the game.
 */
public enum Difficulty {
    /**
     * Standard Difficulty.
     */
    STANDARD,
    /**
     * Easy difficulty, more lives.
     */
    EASY;
}
