package thd.game.level;

/**
 * The first level of Mario.
 */
public class Level1 extends Level{
    /**
     * Initialises the first level.
     */
    public Level1() {
        this.number = 1;
        this.name = "Level " + number + "\nBeginning";
        this.timeLimit = 240;
        this.world = """
                                                                            \s
                                                                            \s
                                                                            \s
                                                                            \s
                    B                                                       \s
                                                                            \s
                                                                            \s
                                                                            \s
                                                                            \s
                     P                                                      \s
          T           M       ST G G G P    S   P     S         S          S\s""";
        this.worldOffsetColumns = 10;
        this.worldOffsetLines = 4;
    }
}
