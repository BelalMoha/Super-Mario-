package thd.game.level;

/**
 * The second level of Mario.
 */
public class Level2 extends Level{
    /**
     * Initialises the second level.
     */
    public Level2() {
        this.number = 2;
        this.name = "Level " + number + "\nLater that day";
        this.timeLimit = 240;
        this.world = """
                                                                          \s
                                                                          \s
                                                                          \s
                                                                          \s
             B                                                            \s
                                                                          \s
                                                                          \s
                                                                          \s
                     C                                                    \s
                                                                          \s
        T           M       ST G G G P    S   P     S         S          S\s""";
        this.worldOffsetColumns = 10;
        this.worldOffsetLines = 4;
    }
}
