package thd.game.level;

/**
 * Class for all information concerning a level.
 */
public class Level {
    /**
     * Name of the Level.
     */
    public String name;
    protected int number;
    /**
     * String representation of the Level.
     */
    public String world;
    /**
     * Vertical Offsets of the level's string representation.
     */
    public int worldOffsetLines;
    /**
     * Horizontal Offsets of the level's string representation.
     */
    public int worldOffsetColumns;
    protected int timeLimit;
    /**
     * Difficulty of the Level.
     */
    public static Difficulty difficulty = Difficulty.STANDARD;
    /**
     * Initialises the base values of a level.
     */
    public Level() {
        this.world = """
                                      \s
                                      \s
          B                           \s
                                      \s
                                      \s
                                      \s
           T              G    G    G \s
                                      \s
                                      \s
                                      \s
        T  T            P             \s""";
        this.worldOffsetColumns = 10;
        this.worldOffsetLines = 4;
    }
}
