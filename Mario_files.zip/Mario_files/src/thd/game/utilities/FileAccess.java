package thd.game.utilities;

import thd.game.level.Difficulty;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Clase to write and access files on disc.
 */
public class FileAccess {
    private static final Path WICHTEL_GAME_FILE = Path.of(System.getProperty("user.home"), new String[0]).resolve("wichtelgame.txt");

    /**
     * Writes Difficulty to Disc.
     *
     * @param difficulty the difficulty.
     */
    public static void writeDifficultyToDisc(Difficulty difficulty) {
        try {
            Files.writeString(WICHTEL_GAME_FILE, difficulty.toString(), new java.nio.file.OpenOption[0]);
        } catch (IOException e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * Reads Difficulty from Disc.
     *
     * @return the difficulty
     */

    public static Difficulty readDifficultyFromDisc() {
        try {
            String difficultyString = Files.readString(WICHTEL_GAME_FILE);
            switch (difficultyString) {
                case "STANDARD":
                    return Difficulty.STANDARD;
                case "EASY":
                    return Difficulty.EASY;
            }
            throw new IOException();
        } catch (IOException e) {
            return Difficulty.STANDARD;
        }
    }
}
