package thd.screens;

import thd.game.level.Difficulty;
import thd.game.utilities.GameView;

/**
 * The Screen at the start of the game.
 */
public class StartScreen {
    private final GameView gameView;
    private Difficulty selectedDifficulty;

    /**
     * Initalises the start screen.
     *
     * @param gameView the applicable gameview.
     */
    public StartScreen(GameView gameView) {
        this.gameView = gameView;
    }

    /**
     * Show a start screen with choices about the difficulty.
     *
     * @param preselectedDifficulty the difficulty selected the previous game.
     */
    public void showStartScreenWithPreselectedDifficulty(Difficulty preselectedDifficulty) {
        boolean easy;
        if (preselectedDifficulty == Difficulty.EASY) {
            easy = gameView.showSimpleStartScreen("Super Mario Bros", "Jump and crush the turts and turds", true);
        } else {
            easy = gameView.showSimpleStartScreen("Super Mario Bros", "Jump and crush the turts and turds", false);
        }
        if (easy) {
            selectedDifficulty = Difficulty.EASY;
        } else {
            selectedDifficulty = Difficulty.STANDARD;
        }
    }

    /**
     * Gets Selected Difficulty.
     *
     * @return Difficulty selected in the start screen.
     */
    public Difficulty getSelectedDifficulty() {
        return selectedDifficulty;
    }
}
