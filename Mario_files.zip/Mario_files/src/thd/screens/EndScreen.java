package thd.screens;

import thd.game.utilities.GameView;

/**
 * The end Screen of the Mario game.
 */
public class EndScreen {
    private final GameView gameView;

    /**
     * The initialisation of the end screen.
     *
     * @param gameView the applicable gameview.
     */
    public EndScreen(GameView gameView) {
        this.gameView = gameView;
    }

    /**
     * Shows the end screen and your score.
     *
     * @param score the points accumulated in the game.
     */
    public void showEndScreen(int score) {
        gameView.showEndScreen("Game Over!\n You have accumulated " + score + "points !");
    }
}
