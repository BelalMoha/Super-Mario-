package thd.gameobjects.base;

/**
 * Game Object that can remain inactive after spawning.
 *
 * @param <T> passes a special object in method
 */
public interface ActivatableGameObject<T> {
    /**
     * Try to activate game Object.
     *
     * @param info an object that can be passed to the game object. Info can be <code>null</code>
     *
     * @return true if activated
     */
    boolean tryToActivate(T info);
}
