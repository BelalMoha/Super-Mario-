package thd.gameobjects.base;

/**
 * A main character of the game that is directly controlled by the user.
 */
public interface MainCharacter {

    /**
     * Main characters are able to shoot.
     */
    void shoot();
}
