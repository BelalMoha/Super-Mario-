package thd.gameobjects.base;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import java.util.Objects;

/**
 * Represents an object in the game.
 */
public abstract class GameObject {

    protected final GamePlayManager gamePlayManager;
    protected final GameView gameView;
    protected final Position position;
    protected final Position targetPosition;
    protected double speedInPixel;
    protected double rotation;
    protected double size;
    protected double width;
    protected double height;
    protected char distanceToBackground;

    /**
     * Crates a new GameObject.
     *
     * @param gameView        GameView to show the game object on.
     * @param gamePlayManager Manages the game play.
     */
    public GameObject(GameView gameView, GamePlayManager gamePlayManager) {
        this.gameView = gameView;
        this.gamePlayManager = gamePlayManager;
        position = new Position();
        targetPosition = new Position();
    }

    /**
     * Updates the status of the game object.
     */
    public void updateStatus() {
    }

    /**
     * Updates the position of the game object.
     */
    public void updatePosition() {
    }
    /**
     * the equal method.
     *
     *  @param o the object to be compared
     * @return boolean stating whether or not they are equal
     */
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        return hashCode() == o.hashCode() && position.equals(((GameObject) o).position)
                && speedInPixel == ((GameObject) o).speedInPixel
                && rotation == ((GameObject) o).rotation
                && size == ((GameObject) o).size
                && width == ((GameObject) o).width
                && height == ((GameObject) o).height
                && targetPosition.equals(((GameObject) o).targetPosition)
                && distanceToBackground == ((GameObject) o).distanceToBackground;
    }
    /**
     * the hash function.
     */
    @Override
    public int hashCode() {
        return Objects.hash(position, speedInPixel, rotation, size, width, height, targetPosition, distanceToBackground);
    }

    /**
     * Draws the game object to the canvas.
     */
    public abstract void addToCanvas();

    /**
     * Getter method for distance to background.
     *
     * @return the distance to background
     */
    public char getDistanceToBackground() {
        return distanceToBackground;
    }

    /**
     * Returns the current position of the game object.
     *
     * @return position of the game object.
     */
    public Position getPosition() {
        return position;
    }


    /**
     * Returns width of game object.
     *
     * @return Width of game object
     */
    public double getWidth() {
        return width;
    }

    /**
     * Returns height of game object.
     *
     * @return Height of game object
     */
    public double getHeight() {
        return height;
    }
}