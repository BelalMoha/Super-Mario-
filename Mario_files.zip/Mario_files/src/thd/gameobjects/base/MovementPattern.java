package thd.gameobjects.base;

import java.util.Random;

/**
 * Represents a movement pattern of a game object.
 */
public class MovementPattern {

    protected final Random random;
    protected int currentIndex;

    protected MovementPattern() {
        random = new Random();
        currentIndex = -1;
    }

    protected Position nextTargetPosition() {
        return new Position();
    }

    protected Position startPosition() {
        return new Position();
    }
}
