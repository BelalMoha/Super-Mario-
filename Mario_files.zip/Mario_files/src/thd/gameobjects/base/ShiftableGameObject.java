package thd.gameobjects.base;

/**
 * Interface for all shiftable objects.
 *
 */
public interface ShiftableGameObject {
}
