package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * The Second background of Mario.
 */
public class Background2 extends GameObject implements ShiftableGameObject {
    /**
     * Initialises the values of the background.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public Background2(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        rotation = 0;
        width = gameView.WIDTH;
        height = gameView.HEIGHT;
        distanceToBackground = 0;
    }

    /**
     * gives the actual position as string.
     *
     * @return the name and position
     */
    @Override
    public String toString() {
        return "Time: " + position.toString();
    }
    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("background.png", position.getX(), position.getY(), 1, 0);
    }
}