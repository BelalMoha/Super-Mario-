package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;

import java.awt.*;

/**
 * The timer for the mission, a standard in Mario.
 */
public class Time extends GameObject {

    /**
     * Initialises the values of the Time.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public Time(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        rotation = 0;
        width = 150;
        height = 33;
        position.updateCoordinates(GameView.WIDTH - width, 0);
        distanceToBackground = 1;
    }

    /**
     * gives the actual position as string.
     *
     * @return the name and position
     */
    @Override
    public String toString() {
        return "Time: " + position.toString();
    }
    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addTextToCanvas("234", position.getX(), position.getY(), size, true, Color.YELLOW, rotation);
    }

}
