package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;

import java.awt.*;

/**
 * For walking and jumping.
 */
public class Platform extends GameObject {
    private final Color brown;
    private Color color;

    /**
     * Creates the meadow with the GameView to be displayed on.
     *
     * @param gameView Window to show the GameObject on.
     * @param gamePlayManager the gameplay view
     */
    public Platform(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        this.brown = Color.yellow.darker().darker().darker().darker();
        this.color = brown;
        this.width = GameView.WIDTH + 2 * 420;
        this.height = 30;
        position.updateCoordinates(-420, GameView.HEIGHT - height);
        distanceToBackground = 0;
    }


    @Override
    public void addToCanvas() {
        gameView.addRectangleToCanvas(position.getX(), position.getY(), width, height, 0, true, color);
    }
}
