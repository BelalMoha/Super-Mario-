package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * A basic block that Mario can jump on.
 */
public class Block extends CollidingGameObject implements ShiftableGameObject {

    /**
     * Crates a new Block, basics of jumping in Mario.
     *
     * @param gameView        GameView to show the game object on.
     * @param gamePlayManager Manages the game play.
     */
    public Block(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        width = 92;
        height = 60;
        rotation = 0;
        position.updateCoordinates(640, 500);
        hitBoxOffsets(0, 0, width, height);
        distanceToBackground = 5;
    }

    @Override
    public void reactToCollisionWith(CollidingGameObject other) {

    }

    /**
     * gives the actual position as string.
     *
     * @return the name and position.
     */
    @Override
    public String toString() {
        return "Block: " + position.toString();
    }

    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("block3.png", position.getX(), position.getY(), 0.4, 0);
    }
}
