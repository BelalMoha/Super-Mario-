package thd.gameobjects.unmovable;

import java.awt.*;

/**
 * Block Images for Blocks in Mario.
 * I know it sounds weird, but Wichtel won't accept it if I just say BlockImages.
 */
class BlockBlockImages {
    static final String BLOCKDISPLAY = """
                OOOOO
                OOOOO
                OOOOO
                OOOOO
                OOOOO
            """;
}
