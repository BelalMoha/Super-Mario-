package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * The iconic Mario tubes.
 */
public class GreenTube extends CollidingGameObject implements ShiftableGameObject {
    /**
     * Initialises the values of the cloud.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public GreenTube(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        rotation = 0;
        width = 60;
        height = 100;
        position.updateCoordinates(width, 565);
        hitBoxOffsets(0, 0, width, height);
        distanceToBackground = 5;
    }
    /**
     * Collisions.
     *
     * @param other The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject other) {
    }

    /**
     * gives the actual position as string.
     *
     * @return the name and position
     */
    @Override
    public String toString() {
        return "Time: " + position.toString();
    }
    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("smalltube.png", position.getX(), position.getY(), 0.3, 0);
    }
}
