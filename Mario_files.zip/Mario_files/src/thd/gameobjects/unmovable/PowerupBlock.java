package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

public class PowerupBlock extends CollidingGameObject implements ShiftableGameObject {

    POWERUPS t;

    /**
     * Crates a new GameObject.
     *
     * @param gameView        GameView to show the game object on.
     * @param gamePlayManager Manages the game play.
     */
    public PowerupBlock(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        width = 60;
        height = 60;
        rotation = 0;
        position.updateCoordinates(GameView.WIDTH/2, GameView.HEIGHT/2);
        distanceToBackground = 5;
        t = POWERUPS.BIG;
    }

    /**
     * Enumeration of the different powerups that mario is able to obtain.
     */
    public enum POWERUPS {
        BIG, FIREBALL, WHITE, BLACK, GOKU;
    }

    private void powerups() {
        if (t == POWERUPS.BIG) {
            size = size*2;
        } else if (t == POWERUPS.FIREBALL) {
        } else if (t == POWERUPS.BLACK) {
        } else if (t == POWERUPS.GOKU) {
        }
    }
    /**
     * Oh Imagine a land,
     * it's a faraway place
     *
     *
     */

    /**
     * Gives the actual position as String.
     *
     * @return the name and the position.
     */
    @Override
    public String toString() {
        return "Power-up Block" + position;
    }

    /**
     * Provides a reaction to collision with another colliding game object.
     *
     * @param other The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject other) {

    }

    /**
     *
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("luckyblock.png",5,6,1,0);
    }
}
