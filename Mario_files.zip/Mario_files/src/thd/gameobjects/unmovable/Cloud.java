package thd.gameobjects.unmovable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.GameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * Generic clouds.
 */
public class Cloud extends GameObject implements ShiftableGameObject {
    /**
     * Initialises the values of the cloud.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public Cloud(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        size = 30;
        rotation = 0;
        width = 150;
        height = 33;
        position.updateCoordinates(GameView.WIDTH/2 - width, 100);
        distanceToBackground = 1;
    }

    /**
     * gives the actual position as string.
     *
     * @return the name and position
     */
    @Override
    public String toString() {
        return "Time: " + position.toString();
    }
    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("clouds.png", position.getX(), position.getY(), 0.3, 0);
        gameView.addImageToCanvas("clouds.png", position.getX() + 200, position.getY(), 0.3, 0);
        gameView.addImageToCanvas("clouds.png", position.getX() + 400, position.getY(), 0.3, 0);
    }
}
