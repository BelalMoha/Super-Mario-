package thd.gameobjects.movable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;

import java.awt.*;

class Fireball extends Shot{
    private String display;
    private State currentState;
    Fireball(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        position.updateCoordinates(GameView.WIDTH / 2d, GameView.HEIGHT / 2d);
        speedInPixel = 3;
        size = 4;
        width = (int) (2 * size);
        height = (int) (4 * size);
        distanceToBackground = 5;
        display = "fireball_1.png";
        currentState = State.FIREBALL_1;
    }

    /**
     * Reaction to Collisions.
     *
     * @param other The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject other) {
        if (other instanceof CheepCheep) {
            gamePlayManager.destroyGameObject(other);
            gamePlayManager.addPoints(100);
        } else if (other instanceof Goomba) {
            gamePlayManager.addPoints(100);
        } else if (other instanceof Turtle) {
            gamePlayManager.destroyGameObject(other);
            gamePlayManager.addPoints(100);
        }
    }

    private enum State {
        FIREBALL_1("fireball_1.png"), FIREBALL_2("fireball_2.png"), FIREBALL_3("fireball_3.png"), FIREBALL_4("fireball_4.png");
        private String spaza;
        State(String spaza) {
            this.spaza = spaza;
        }
    }
    @Override
    public void updatePosition() {
        position.right(speedInPixel);
    }

    @Override
    public void updateStatus() {
        if (position.getY() + height < 0) {
            gamePlayManager.destroyGameObject(this);
        }
        switch (currentState) {
            case FIREBALL_1, FIREBALL_2, FIREBALL_3, FIREBALL_4 -> {
                display = currentState.spaza;
                if (gameView.timer(80, this)) {
                    switchToNextState();
                }
            }
        }
    }
    private void switchToNextState() {
        int nextState = (currentState.ordinal() + 1) % State.values().length;
        currentState = State.values()[nextState];
    }

    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas(display, position.getX(), position.getY() + 10, size, rotation);
    }
}
