package thd.gameobjects.movable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.MainCharacter;
import thd.gameobjects.base.Position;
import thd.gameobjects.unmovable.Block;
import thd.gameobjects.unmovable.GreenTube;

/**
 * The Main character is here.
 */
public class Mario extends CollidingGameObject implements MainCharacter {
    private final int shotDurationInMilliseconds;
    private final GreenTube greenTube;
    private State currentState;
    private String display;
    private RunningState runningState;
    private RunningToRight runningToRight;
    private Position blockPosition;
    private Position pipePosition;
    private boolean onblock;
    private boolean onpipe;
    private RunningToLeft runningToLeft;
    private JumpingState jumpingState;
    /**
     * Crates Mario.
     *
     * @param gameView Window to show the GameObject on.
     * @param gamePlayManager the gameplay view
     * @param greenTube the tube for collisions.
     */
    public Mario(GameView gameView, GamePlayManager gamePlayManager, GreenTube greenTube) {
        super(gameView, gamePlayManager);
        shotDurationInMilliseconds = 300;
        size = 3;
        speedInPixel = 5;
        width = (int) (25 * size);
        height = (int) (10 * size);
        position.updateCoordinates((GameView.WIDTH - width) / 2d, 545);
        hitBoxOffsets(0, 0, 0, 0);
        distanceToBackground = 5;
        currentState = State.STANDARD;
        display = "mario2.png";
        runningState = RunningState.RUNNING_1;
        jumpingState = JumpingState.JUMPING_STATE1;
        runningToLeft = RunningToLeft.RUNNING_1;
        runningToRight = RunningToRight.RUNNING_1;
        this.greenTube = greenTube;
        onblock = false;
        blockPosition = new Position();
        onpipe = false;
        pipePosition = new Position();
    }


    @Override
    public void reactToCollisionWith(CollidingGameObject other) {
        if (other instanceof Goomba) {
            gamePlayManager.addPoints(100);
        }
        if (other instanceof Block temp && currentState == State.JUMPING) {
            position.updateCoordinates(position.getX(), 545 - 120);
            currentState = State.STANDARD;
            onblock = true;
            blockPosition.updateCoordinates(temp.getPosition());
        }
        if (other instanceof GreenTube tem && currentState == State.JUMPING) {
            position.updateCoordinates(position.getX(), 545 - 100);
            currentState = State.STANDARD;
            onpipe = true;
            pipePosition.updateCoordinates(tem.getPosition());
        }
    }

    /**
     * The Iconic, The one and only MARIO JUMP.
     *
     * Short jump only for copyright reasons, we hope you understand.
     */
    public void jump() {
        if (currentState != State.JUMPING) {
            currentState = State.JUMPING;
            gameView.playSound("jump.wav", false);
        }
    }

    private enum State {
        STANDARD, RUNNING_1, RUNNING_2, JUMPING;
    }
    private enum JumpingState {
        JUMPING_STATE1("mario2.png", 0), JUMPING_STATE2("runningsmall.png", 100), JUMPING_STATE3("runningsmall.png", 60),
        JUMPING_STATE4("runningsmall.png", 0), JUMPING_STATE5("runningsmall.png", -100), JUMPING_STATE6("runningsmall.png", -60),
        JUMPING_STATE7("runningsmall.png", 0), JUMPING_STATE8("mario2.png", 0);
        private String display;
        private int up;
        JumpingState(String display, int up) {
            this.display = display;
            this.up = up;
        }
    }

    /**
     * Mario will go to the left.
     */
    public void left() {
        if (position.getX() > GameView.WIDTH / 2d - 200) {
            position.left(speedInPixel);
        } else {
            gamePlayManager.moveWorldToRight(speedInPixel);
        }
        if (currentState == State.STANDARD) {
            currentState = State.RUNNING_1;
        }
        if (collidesWith(greenTube)) {
            position.right(speedInPixel);
        }
        if (onblock) {
            blockPosition.right(speedInPixel);
        }
        if (onpipe) {
            pipePosition.right(speedInPixel);
        }
    }

    /**
     * Mario will go to the right.
     */
    public void right() {
        if (position.getX() > 840) {
            position.right(speedInPixel);
        } else {
            gamePlayManager.moveWorldToLeft(speedInPixel);
        }
        if (currentState == State.STANDARD){
            currentState = State.RUNNING_2;
        }
        if (collidesWith(greenTube)) {
            position.left(speedInPixel);
        }
        if (onblock) {
            blockPosition.left(speedInPixel);
        }
        if (onpipe) {
            pipePosition.left(speedInPixel);
        }
    }

    /**
     * Mario will shoot.
     */
    @Override
    public void shoot() {
        if (gameView.timer(shotDurationInMilliseconds, this)) {
            Fireball fireball = new Fireball(gameView, gamePlayManager);
            fireball.getPosition().updateCoordinates(position.getX() + width / 2d, position.getY() - 5);
            gamePlayManager.spawnGameObject(fireball);
            gameView.playSound("fireball.wav", false);
        }
    }

    private void switchToNextState() {
        int nextState = (currentState.ordinal() + 1) % State.values().length;
        currentState = State.values()[nextState];
    }

    @Override
    public void updateStatus() {
        switch (currentState) {
            case STANDARD -> {
                resetState();
            }
            case RUNNING_1 -> {
                display = runningToRight.display;
                if (gameView.timer(241, this)) {
                    resetState();
                }
                if (gameView.timer(80, this)) {
                    switchToNextRightRunningState();
                }
            }
            case RUNNING_2 -> {
                display = runningToLeft.display;
                if (gameView.timer(241, this)) {
                    resetState();
                }
                if ((gameView.timer(80, this))) {
                    switchToNextLeftRunningState();
                }
            }
            case JUMPING -> {
                display = jumpingState.display;
                if (gameView.timer(80, this)) {
                    switchToNextJumpingState();
                    position.updateCoordinates(position.getX(), position.getY() - jumpingState.up);
                }
            }
        }
        if (onblock && (blockPosition.getX() + 184 < getPosition().getX() || position.getX() + width * 2 < blockPosition.getX())) {
            onblock = false;
            getPosition().down(120);
        }
        if (onpipe && (pipePosition.getX() + 120 < getPosition().getX() || position.getX() + width * 2 < pipePosition.getX())) {
            onpipe = false;
            getPosition().down(100);
        }
        if (jumpingState == JumpingState.JUMPING_STATE8) {
            resetState();
        }
    }
    private void resetState() {
        currentState = State.STANDARD;
        runningToRight = RunningToRight.RUNNING_1;
        jumpingState = JumpingState.JUMPING_STATE1;
        display = JumpingState.JUMPING_STATE1.display;
    }
    private void switchToNextRightRunningState() {
        int nextState = (runningToRight.ordinal() + 1) % RunningToRight.values().length;
        runningToRight = RunningToRight.values()[nextState];
    }
    private void switchToNextLeftRunningState() {
        int nextState = (runningToLeft.ordinal() + 1) % RunningToLeft.values().length;
        runningToLeft = RunningToLeft.values()[nextState];
    }
    private void switchToNextJumpingState() {
        int nextState = (jumpingState.ordinal() + 1) % JumpingState.values().length;
        jumpingState = JumpingState.values()[nextState];
    }
    private boolean shouldStandOnObject(CollidingGameObject other) {
        if (other instanceof GreenTube || other instanceof Block) {
            return true;
        }
        return false;
    }

    private enum RunningState {
        RUNNING_1("mariosmall.png"), RUNNING_2("runningsmall.png"),
        RUNNING_3("runningsmall.png"), RUNNING_4("mariosmall.png"), RUNNING_5("");
        private String display;
        RunningState(String display) {
            this.display = display;
        }
    }
    private enum RunningToLeft {
        RUNNING_1("running1.png"), RUNNING_2("running2.png"), RUNNING_3("running3.png");
        private String display;

        RunningToLeft(String display) {
            this.display = display;
        }
    }
    private enum RunningToRight {
        RUNNING_1("running11.png"), RUNNING_2("running22.png"), RUNNING_3("running33.png");
        private String display;
        RunningToRight(String display) {
            this.display = display;
        }
    }

    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas(display, position.getX(), position.getY() + 20, size, rotation);
    }
}
