package thd.gameobjects.movable;

import thd.game.utilities.GameView;
import thd.gameobjects.base.MovementPattern;
import thd.gameobjects.base.Position;

class CheepCheepMovementPattern extends MovementPattern {

    private final double positionLeft;
    private final double positionRight;
    private boolean fliesFromLeftToRight;
    private final double sinkingSpeed;
    private final int minimumFlyingHeight;
    private double altitude;

    CheepCheepMovementPattern(double ufoWidth) {
        minimumFlyingHeight = GameView.HEIGHT - 150;
        positionLeft = -100;
        positionRight = GameView.WIDTH + ufoWidth + 100;
        altitude = 10;
        sinkingSpeed = 100;
    }

    @Override
    protected Position nextTargetPosition() {
        sinkingAnimation();
        fliesFromLeftToRight = !fliesFromLeftToRight;
        return fliesFromLeftToRight ? new Position(positionRight, altitude) : new Position(positionLeft, altitude);
    }

    private void sinkingAnimation() {
        altitude += sinkingSpeed;
        if (altitude > minimumFlyingHeight) {
            altitude -= 2 * sinkingSpeed;
        }
    }

    @Override
    protected Position startPosition() {
        fliesFromLeftToRight = true;
        return new Position(-100, 100);
    }
}