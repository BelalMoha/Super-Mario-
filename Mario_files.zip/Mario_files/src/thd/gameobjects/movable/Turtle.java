package thd.gameobjects.movable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * Initialises the normal creep, Turtle.
 */
public class Turtle extends CollidingGameObject implements ShiftableGameObject {

    /**
     * Initialises the Turtle's values.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public Turtle(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        position.updateCoordinates(GameView.WIDTH, 565);
        rotation = 0;
        size = 30;
        width = 50;
        height = 33;
        speedInPixel = 5;
        hitBoxOffsets(0, 0, 0, 0);
        distanceToBackground = 5;
    }

    /**
     * gives the turtle's position.
     *
     * @return current position.
     */
    @Override
    public String toString() {
        return "Turtle: " + position;
    }
    /**
     * Collisions.
     *
     * @param other The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject other) {
        if (other instanceof Mario) {
            gamePlayManager.loseLife();
            gameView.playSound("kick.wav", false);
        }
    }

    /**
     * Position updater.
     */
    @Override
    public void updatePosition() {
        position.left(speedInPixel);
    }
    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("turtle.png", position.getX(), position.getY() - 30, 0.3, 0);
    }
}
