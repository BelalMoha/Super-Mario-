package thd.gameobjects.movable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

import java.util.Random;

/**
 * Initialises a Cheepcheep, the flying monster.
 */
public class CheepCheep extends CollidingGameObject implements ShiftableGameObject {
    private final Random random;
    private final CheepCheepMovementPattern cheepCheepMovementPattern;
    /**
     * Initialises the Cheepcheep's position and values.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public CheepCheep(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        random = new Random();
        speedInPixel = 2 * (1 + random.nextInt(4));
        size = 2 + random.nextInt(3);
        width = 24 * size;
        height = 9 * size;
        cheepCheepMovementPattern = new CheepCheepMovementPattern(width);
        position.updateCoordinates(cheepCheepMovementPattern.startPosition());
        targetPosition.updateCoordinates(cheepCheepMovementPattern.nextTargetPosition());
        hitBoxOffsets(0, 0, 0, 0);
        distanceToBackground = 5;
    }
    /**
     * Collisions.
     *
     * @param hehe The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject hehe) {
        if (hehe instanceof Fireball) {
            gamePlayManager.destroyGameObject(this);
        }
    }

    /**
     * transforms the Cheepcheep's position to string.
     *
     * @return the name and position
     */
    @Override
    public String toString() {
        return "Cheepcheep: " + position.toString();
    }

    /**
     * Position Updater.
     */
    @Override
    public void updatePosition() {
        position.moveToPosition(targetPosition, speedInPixel);
        if (position.similarTo(targetPosition)) {
            targetPosition.updateCoordinates(cheepCheepMovementPattern.nextTargetPosition());
        }
        swingingAnimation();
    }

    private void swingingAnimation() {
        position.down(Math.round(Math.sin(Math.toRadians(position.getX() * 2))));
    }

    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas("cheepcheeps.png", position.getX(), position.getY(), 0.1, rotation);
    }
}
