package thd.gameobjects.movable;

import thd.game.managers.GamePlayManager;
import thd.game.utilities.GameView;
import thd.gameobjects.base.ActivatableGameObject;
import thd.gameobjects.base.CollidingGameObject;
import thd.gameobjects.base.ShiftableGameObject;

/**
 * Initialises the basic enemy Goomba.
 */
public class Goomba extends CollidingGameObject implements ShiftableGameObject, ActivatableGameObject<Integer> {
    private State currentState;
    private String display;
    /**
     * Initialises the goomba's values.
     *
     * @param gameView the applicable gameview
     * @param gamePlayManager the gameplay view
     */
    public Goomba(GameView gameView, GamePlayManager gamePlayManager) {
        super(gameView, gamePlayManager);
        position.updateCoordinates(gameView.WIDTH, 565);
        rotation = 0;
        size = 30;
        width = 50;
        height = 33;
        speedInPixel = 5;
        hitBoxOffsets(0, 0, 0, 0);
        distanceToBackground = 5;
        display = "goomba.png";
        currentState = State.STANDARD;
    }

    /**
     * gives the goomba's position.
     *
     * @return current position.
     */
    @Override
    public String toString() {
        return "Turtle: " + position;
    }

    /**
     * Collisions.
     *
     * @param other The other game object that is involved in the collision.
     */
    @Override
    public void reactToCollisionWith(CollidingGameObject other) {
        if (other instanceof Mario) {
            gamePlayManager.loseLife();
            switchToNextState();
            gameView.playSound("kick.wav", false);
        } else if (other instanceof Fireball) {
            switchToNextState();
            gameView.playSound("kick.wav", false);

        }
    }
    private enum State {
        STANDARD("goomba.png"), FLATTENED("flat_goomba.png");
        private String display;
        State(String display) {
            this.display = display;
        }
    }

    /**
     * Position updater.
     */
    @Override
    public void updatePosition() {
        if (currentState != State.FLATTENED) {
            position.left(speedInPixel);
        }
    }
    @Override
    public void updateStatus() {
        switch (currentState) {
            case STANDARD -> {
                display = currentState.display;
            }
            case FLATTENED -> {
                display = currentState.display;
                if (gameView.timer(100, this)) {
                    gamePlayManager.destroyGameObject(this);
                }
            }
        }
    }
    private void switchToNextState() {
        int nextState = (currentState.ordinal() + 1) % State.values().length;
        currentState = State.values()[nextState];
    }

    /**
     * gives actual position and image on the object.
     */
    @Override
    public void addToCanvas() {
        gameView.addImageToCanvas(display, position.getX(), position.getY(), 0.3, 0);
    }

    @Override
    public boolean tryToActivate(Integer info) {
        return gameView.timer(info, this);
    }
}
